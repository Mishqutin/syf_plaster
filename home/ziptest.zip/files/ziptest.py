

class COMMAND_CLASS:
    
    def ziptest(cmd, args, cData):
        msg = "Yay, you have successfuly installed ziptest!"
        return {"msg": msg}

COMMANDS["ziptest"] = COMMAND_CLASS.ziptest