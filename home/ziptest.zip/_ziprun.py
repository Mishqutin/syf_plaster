import os

ROOT_APPS_PATH = ROOT_PATH+"/apps"
SYS_PATH = ROOT_PATH+"/system"

# Load needed libs

f = open(SYS_PATH+"/execlibs/client.py", 'r')
code = f.read()
f.close()

exec(code, globals())


# Install

print("Making dirs...")
os.mkdir(ROOT_APPS_PATH+"/ziptest")
os.mkdir(ROOT_APPS_PATH+"/ziptest/shell")

print("Writing..")
code = zip.read("files/ziptest.py")

f = open(ROOT_APPS_PATH+"/ziptest/shell/ziptest.py", 'wb')
f.write(code)
f.close()

# System call

IP = ("localhost", 12345)
KEY = "123456"

data = {"name": "ziptest-app", "key": KEY, "string": "reload"}

res = Client.connect(IP, data)

print(res)
print("Done.")

